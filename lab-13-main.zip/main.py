# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
'''print ("Привет, как тебя зовут.")
a = input("ввод")
print ("Рад познакомится", a)
print ("На каком курсе ты учишся.")
while True:
    try:
        b = int(input("Ввод: "))
        break
    except ValueError:
        print("Вы ввели не верные данные необходимо ввести только числа")
print ("Сколько тебе лет")
while True:
    try:
        c = int(input("Ввод: "))
        break
    except ValueError:
        print("Вы ввели не верные данные необходимо ввести только числа")
d = c+4-b
print ("По оканчанию курса те будет", d)'''
print("задание 1")
girls = ["Иветта", "Виолетта", "Кассандра", "Вирджиния", "Амелия", "Розамунда", "Янина",  "Беатриса"]
girls2 = [girls[2],girls[4],girls[6]]
print(girls[1:5])
print(girls[3:8])
print(girls[0:4])
print(girls2)
print("задание 2")
import math
'''L = [12, 3, 8, 125, 10, 98, 54, 199]
i = 0
while i < 8:
    print(math.log(L[i]))
    i += 1
print("Изменение элемента")
L[4] = 0
i = 0
while i < 8:
    print(math.log(L[i]))
    i += 1
#ошибка возникает из-за не возможности такого выражения log0
'''
print("задание 2 ошибка возникает из-за не возможности такого выражения log0")
print("задание 3")
age = [24, 35, 42, 27, 45, 48, 33]
age2 =[]
i = 0
while i < 7:
    d = ((age[i])**2)
    assert isinstance(d, object)
    age2.append(d)
    i += 1
print(age2)
print("задание 4")
numbers = [1, 5, 6, 8, 10, 21, 25, 1, 0, -9, 9]
a = int(input("Ввод: "))
b = a-1
print(numbers[b])


